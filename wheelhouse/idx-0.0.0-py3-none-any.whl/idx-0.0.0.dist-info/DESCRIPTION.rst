# python-idx
Placeholder package for [python-homegate](https://github.com/arteria/python-homegate). python-homegate works with 

* [Homegate](http://www.homegate.ch/)
* [Immoscout24](http://www.immoscout24.ch/)
* probably all other IDX3.01 compatible services

and will be refactored to [python-idx](https://github.com/arteria/python-idx/) it the future.


